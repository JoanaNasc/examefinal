<div class="col-md-12">
    <table class="table table-sm">
        <tr>
            <th>User</th>
            <th>Operation</th>
            <th>Description</th>
            <th>Time</th>
        </tr>
        <?php foreach($this->logs as $log){?>
        <tr>
            <td><?php echo $log->username?></td>
            <td><?php echo $log->operation?></td>
            <td><?php echo $log->description?></td>
            <td><?php echo $log->timestamp?></td>
        </tr>
        <?php }?>
    </table>
</div>