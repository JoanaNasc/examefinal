<?php

?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Exame Final Homepage">
        <meta name="keywords" content="HTML">
        <meta name="author" content="Joana">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <title>Homepage</title>
        <style>
            navegation ul li {
                display: inline;
                margin-right: 1em;
            }
            table, th, td {
                border: 1px solid black;
            }
            .footer {
                left: 0;
                bottom: 0;
                width: 100%;
                color: black;
                text-align: center;
                position: relative;
            }
            h1{
                text-align: center;
            }
        </style>
    </head>
    <body>
        <navegation>
            <ul>
                <?php if(app\controller\UserController::is_logged_in()) {?>
                    <li>User: <?php echo $_SESSION['username'];?></li>
                    <li><a href="/logout">Logout</a></li>
                    <li><a href="/logs">List Logs</a></li>
                    <li><a href="/user/list">List Users</a></li>
                    <li><a href="/zip">Zip</a></li>
                <?php } ?>
            </ul>
        </navegation>
        <?php 
        if(count($this->errors)!==0){
        echo '<p> You have errors:<br/></p>';
        echo '<ul>';
        foreach ($this->errors as $key => $error) {
            echo '<li>'.$error.'</li>';
        }
        echo '</ul>';
    }?>