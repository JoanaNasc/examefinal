<div id="content">
  <div class="col-md-6 user new">
    <h1>Register</h1>
    <form action="/user/create" method="post">
        <dl>
            <dt>Email</dt>
            <dd><input type="email" name="email" value="<?php echo isset($this->vars['user'])? $this->user->email: ''?>" /></dd>
        </dl>
        <dl>
            <dt>Username</dt>
            <dd><input type="text" name="username" value="<?php echo isset($this->vars['user'])?$this->user->username : ''?>" /></dd>
        </dl>

        <dl>
            <dt>Password</dt>
            <dd><input type="password" name="password" value="" /></dd>
        </dl>

        <dl>
            <dt>Confirm Password</dt>
            <dd><input type="password" name="confirm_password" value="" /></dd>
        </dl>

        <div id="operations">
            <input type="submit" value="Create User" />
        </div>
    </form>
  </div>
</div>
