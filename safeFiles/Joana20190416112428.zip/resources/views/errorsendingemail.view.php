<p>
Sorry we could not send the email. Please contact the administrator for the email:
    <strong>jnascimento@growin.pt</strong>
</p>
<a href="/">Go to Homepage</a>