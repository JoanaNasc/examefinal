<?php
namespace tests;

require dirname(dirname(__FILE__)).'/vendor/autoload.php';

use PHPUnit\Framework\TestCase;

use app\controller\UserController;

class UserControllerTest extends TestCase{

    public function setUp():void{ 
        $this->user=new UserController();
    }

    public function tearDown():void{
        unset($this->user);
    }
    
    public function testLogin(){
        $args['username'] = 'JoanaNasc';
        $args['password'] = 'Jnascimento123*';
       /* $response = $this->user->login($args);
        $response->assertSuccessful();
        $response->assertViewIs('auth.login');*/
    }
}
?>