<div id="content">
    <h1>Welcome to my Final Exame Page </h1>
    <form action="/user/" method="post" class="col-md-6">
        <div class="form-group">
            Username:
            <input type="text" class="form-control" name="username" placeholder="Enter username" >
        </div>
        <div class="form-group">
            Password:
            <input type="password" class="form-control" name="password" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </form>

    <p class="col-md-6">If you need Registe please click here:<a href="/user/new">Register</a></p>
</div>
