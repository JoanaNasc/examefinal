<?php
namespace app\controller;

use app\user;
use vendor\MyView;
use vendor\Functions;
use app\controller\LogController;
use app\controller\SwiftMailerController;
/*
    Classe para executar os metodos de user:
        -> login
        -> logout
        -> new
        -> create
        -> is_logged_in
        -> confirmemail
*/
class UserController{

    /*
        displayWelcome:
            -> se o utlizador estiver logado manda para o indexes para mostrar os dados
            -> se nao houver utilizador logado manda fazer o login
    */
    public static function displayWelcome(){
        $myview = new MyView();
        if(isset($_SESSION['username'])){
            //header('Location:/indexes');
            header('Location:/logs');
        }else{
            $myview->render('login.view.php');
        }
    }
    /*  
        login:
            -> verifica se o username e a password estão em branco. Se estiver devolve um erro
            -> Chama as funcçoes de find_by_username e verify_password do modelo User para confirmar se existe e se pode ser logado
            -> Se estiver tudo bem grava o username na variavel global $_SESSION
            -> senao faz render e envia os erros de volta
    */
    public static function login($args){ 
        $errors=[]; 
        
        $myview = new MyView();
        $username=isset($args['username'])?$args['username'] :'';
        $password=isset($args['password'])?$args['password']:'';

        if(Functions::isblank($username)){
           $errors[]= 'Username cannot be blank!';
        }
        if(Functions::isblank($password)){
            $errors[] .= 'Password cannot be blank!';
        }
        
        if(count($errors)==0){
            $userExists= User::find_by_username($username);
            $passwordIsCorrect = $userExists->verify_password($password);
            if($userExists && $passwordIsCorrect && strcmp($userExists->hash_confirm,'confirmed')==0){
                $time=date('Y-m-d H:i:s');
                User::update_last_login($userExists->id,$time);
                $_SESSION['username']=$username;

                $argsToLog ['request'] = 'Login';
                $argsToLog ['description'] = 'Login from ip:'.$_SERVER['REMOTE_ADDR'];
                LogController::post($argsToLog);
               // header('Location:/indexes');
               header('Location:/logs');
            }else{
                $errors[] = 'Username or Password wrong!';
                $myview->errors=$errors;
                $myview->render('login.view.php');
            }
        }else{
            $myview->errors=$errors;
            $myview->render('login.view.php');
        }
    }

    /*
        new:
            ->Faz render da view create_user
    */
    public static function new(){
        $myview = new MyView();
        $myview->render('create_user.view.php');
    }

    /*
        create:
            -> cria um novo utilizador
            -> valida com a funçao validate do modelo User se os campos estão todos correctos 
            -> chama o metodo create do modelo User para criar o utilizador, 
                se der erro devolve o erro e faz render do mesmo formulario senão manda email e mensagem para o slack, e faz render para 
                a pagina de login
            -> chama o LogController para guardar os logs
    */
    public static function create($args){
        $myview = new MyView();
        $user = new User();
        
        $user->email = $args['email'];
        $user->username = $args['username'];
        $user->password = $args['password'];
        
        $user->confirm_password = $args['confirm_password'];
        $user->last_login = date('Y-m-d H:i:s');

        $errors = self::validate($user);

        if(!empty($errors)){
            $myview->errors=$errors;
            $myview->user=$user;
            $myview->render('create_user.view.php');
        }else{            
            $created=$user->create();
            if($created){
                $argsToLog ['username'] = $user->username;
                $argsToLog ['request'] = 'Create User';
                $argsToLog ['description'] = 'User Create from ip:'.$_SERVER['REMOTE_ADDR'];
                LogController::post($argsToLog);
                //enviar e-mail
                $token = bin2hex($user->email);//token gerado a partir do email   
                $message = "We received a registration on our page with this email, please follow the link below to confirm:
                    <strong>\"http://examefinal.test/confirmemail/{$token}\"</strong><br/>
                <h6>If you have not registered, please ignore this email.</h6>";

                $message = <<<EOT
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Confirm Email Test</title>
</head>
<body link="#B64926" vlink="#FFB03B">
We received a registration on our page with this email, please follow the link below to confirm:
<strong>http://examefinal.test/confirmemail/{$token}</strong><br/>
<h6>If you have not registered, please ignore this email.</h6>
</body>
</html>
EOT;
                $title ="Confirm Email";
                $email=SwiftMailerController::sendEmail($user->email,$message,$title);
                if($email){
                    $argsToLog ['username'] = $user->username;
                    $argsToLog ['request'] = 'Send Email';
                    $argsToLog ['description'] = 'Email sent to: '.$user->email;
                    LogController::post($argsToLog);
                    //Functions::messageToSlack(strip_tags($message));
                    $myview->render('login.view.php');
                }else{
                    $argsToLog ['username'] = $user->username;
                    $argsToLog ['request'] = 'Send Email';
                    $argsToLog ['description'] = 'Error sending email to: '.$user->email;
                    LogController::post($argsToLog);
                    $myview->render('errorsendingemail.view.php');
                }
            }else{
                $argsToLog ['username'] = $user->username;
                $argsToLog ['request'] = 'Send Email';
                $argsToLog ['description'] = 'Error sending email to: '.$user->email;
                LogController::post($argsToLog);
                $errors[]="Error creating user.Please try again.";
                $myview->errors=$errors;
                $myview->render('create_user.view.php');
            }
            
        }  
    }

    /*
        logout:
            -> chama o LogController para guardar os logs
            -> faz unset da Session['username']
            -> reenvia para o homepage
    */
    public static function logout(){ 
        LogController::post(['request'=>'Logout','description'=>'Logout from ip:'.$_SERVER['REMOTE_ADDR']]);
        $myview = new MyView();
        unset($_SESSION['username']);
        header('Location:/');
        exit;
    }

    /*
        is_logged_in:
            -> verifica se estamos logados chamado o modelo de User
    */
    public static function is_logged_in(): bool {
        return User::is_logged_in();
    }
    /*
        list:
            -> chama a funçao find_all do modelo de User para mostrar todos os utilizadores
            -> faz render do que recebe para user_list
    */
    public static function list(){
        LogController::post(['request'=>'List','description'=>'List all users']);
        $users= User::find_all();
        $myview = new MyView();
        $myview->users=$users;
        $myview->render('user_list.view.php');
    }

    /*
        confirmemail:
            -> recebe o hash enviado por email/slack e chama a funçao confirm_hash do modelo para validar
    */

    public static function confirmemail($args){
        $errors=[];
        $hash=$args['hash'];
        $confirmedHash=User::confirm_hash($hash);
        $myview = new MyView();
        if($confirmedHash!==0){
            LogController::post(['request'=>'Confirm Email','description'=>'Email confirmed from ip:'.$_SERVER['REMOTE_ADDR']]);
            header('Location:/');
        }else{
            $message="We were unable to verify your registration. Please try again.
            http://examefinal.test/confirmemail/{$hash}";
            LogController::post(['request'=>'Confirm Email','description'=>$message]);
            $errors[]=$message;
            $myview->errors=$errors;
            $myview->render('login.view.php');
        }
    }

    //faz as validações precisas para ver se podemos criar um novo registo.
    public static function validate($user) {
        $errors = [];
      
        if(Functions::isblank($user->email)) {
            $errors[] = "Email cannot be blank.";
        } elseif (!Functions::has_length($user->email, array('max' => 255))) {
            $errors[] = "Last name must be less than 255 characters.";
        } elseif (!Functions::validateEmail($user->email)) {
            $errors[] = "Email must be a valid format.";
        }else if( !$user->has_unique_email($user->email,$user->id ?? 0)){
            $errors[] = "Email not allowed. Try another!";
        }
        
        if(Functions::isblank($user->username)) {
          $errors[] = "Username cannot be blank.";
        } else if (!Functions::has_length($user->username, array('min' => 8, 'max' => 255))) {
          $errors[] = "Username must be between 8 and 255 characters.";
        }else if( !$user->has_unique_username($user->username,$user->id ?? 0)){
            $errors[] = "Username not allowed. Try another!";
        }
        //if($user->password_required){ descomentar ser for preciso fazer update senao apagar
            if(Functions::isblank($user->password)) {
            $errors[] = "Password cannot be blank.";
            } elseif (!Functions::has_length($user->password, array('min' => 12))) {
            $errors[] = "Password must contain 12 or more characters";
            } elseif (!preg_match('/[A-Z]/', $user->password)) {
            $errors[] = "Password must contain at least 1 uppercase letter";
            } elseif (!preg_match('/[a-z]/', $user->password)) {
            $errors[] = "Password must contain at least 1 lowercase letter";
            } elseif (!preg_match('/[0-9]/', $user->password)) {
            $errors[] = "Password must contain at least 1 number";
            } elseif (!preg_match('/[^A-Za-z0-9\s]/', $user->password)) {
            $errors[] = "Password must contain at least 1 symbol";
            }
        
            if(Functions::isblank($user->confirm_password)) {
            $errors[] = "Confirm password cannot be blank.";
            } elseif ($user->password !== $user->confirm_password) {
            $errors[] = "Password and confirm password must match.";
            }
        //}
        return $errors;
    }
}


?>